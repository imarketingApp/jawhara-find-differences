# Jawhara Find Differences — GitHub Pages

ارفع الملفات إلى Repository عام على GitHub، ثم:
Settings → Pages → Deploy from a branch → main → /(root) → Save

بعد النشر ستكون الروابط مثل:
https://USERNAME.github.io/REPOSITORY/
https://USERNAME.github.io/REPOSITORY/privacy.html
https://USERNAME.github.io/REPOSITORY/terms.html
https://USERNAME.github.io/REPOSITORY/support.html
